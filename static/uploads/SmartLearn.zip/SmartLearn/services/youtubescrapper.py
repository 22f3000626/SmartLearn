from yt_dlp import YoutubeDL
from transformers import pipeline

# Initialize a zero-shot classifier
classifier = pipeline("zero-shot-classification", model="facebook/bart-large-mnli")

def search_youtube(topic):
    query = f"ytsearch10:{topic} -shorts"  # Search top 10 results excluding Shorts
    ydl_opts = {
        'quiet': True,
        'skip_download': True,
        'extract_flat': False,  # Get full video metadata including duration
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4'
    }

    with YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(query, download=False)
        entries = info.get('entries', [])

        candidates = []
        for entry in entries:
            title = entry.get('title')
            video_id = entry.get('id')
            duration = entry.get('duration')  # in seconds
            if not video_id or not title or not duration:
                continue
            if duration < 300:  # Less than 5 minutes
                continue

            thumbnail = entry.get('thumbnail')
            if isinstance(entry.get('thumbnails'), list) and not thumbnail:
                thumbnails = entry.get('thumbnails', [])
                if thumbnails:
                    thumbnail = thumbnails[-1].get('url')

            candidates.append({
                'title': title,
                'url': f"https://www.youtube.com/watch?v={video_id}",
                'thumbnail': thumbnail,
                'duration': duration
            })

        if not candidates:
            return []

        # Use zero-shot classification to re-rank by relevance to the topic
        titles = [video['title'] for video in candidates]
        results = classifier(titles, candidate_labels=[topic], multi_label=False)

        # Attach scores and sort
        for i, video in enumerate(candidates):
            video['score'] = results[i]['scores'][0]  # Score for the topic label

        top_videos = sorted(candidates, key=lambda x: x['score'], reverse=True)[:5]
        return top_videos
