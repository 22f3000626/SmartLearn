gsap.from(".btn btn-primary",{
    y:-20
    duration:0.7
})



